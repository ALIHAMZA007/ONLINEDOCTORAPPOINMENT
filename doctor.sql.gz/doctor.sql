--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `appoinment`
--

CREATE TABLE `appoinment` (
  `PATIENT` text NOT NULL,
  `SITUATION` varchar(255) NOT NULL,
  `SPEC` text NOT NULL,
  `DAY` text NOT NULL,
  `DAT` date NOT NULL,
  `TIM` time(6) NOT NULL,
  `VENUE` varchar(255) NOT NULL,
  `DOCTOR` text NOT NULL,
  `USERNAME` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `NAME` text NOT NULL,
  `CONTNUM` int(255) NOT NULL,
  `EMAIL` varchar(255) CHARACTER SET latin1 NOT NULL,
  `AGE` int(255) NOT NULL,
  `GENDER` text CHARACTER SET latin1 NOT NULL,
  `TIM` time(6) NOT NULL,
  `SITUATION` int(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `DAY` text NOT NULL,
  `DOCTORNAME` text NOT NULL,
  `SPEC` text NOT NULL,
  `DAT` date NOT NULL,
  `VENUE` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `doc`
--

CREATE TABLE `doc` (
  `NAME` text NOT NULL,
  `CONTNUM` int(25) NOT NULL,
  `SKYPEID` varchar(30) NOT NULL,
  `SPEC` varchar(30) NOT NULL,
  `EXP` varchar(30) NOT NULL,
  `PCI` varchar(2000) NOT NULL,
  `USER` varchar(30) NOT NULL,
  `PASS` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doc`
--

INSERT INTO `doc` (`NAME`, `CONTNUM`, `SKYPEID`, `SPEC`, `EXP`, `PCI`, `USER`, `PASS`) VALUES
('nslnkan', 0, 'mn.bm,', 'PULMONOLOGIST', '  ,m ,', ' ,m m, ,', 'abc', '123'),
('xsn mn x', 8098098, 'knklnn89', 'PULMONOLOGIST', 'knkln', 'kkjbjbjk', 'hamza007', '456'),
('hgjh', 808098, 'hamza_alihamza@outlook.com', 'GENERAL SURGEON', 'alihamza_505@yahoo.com', 'bhjbhjjh', 'raffy', '789');

-- --------------------------------------------------------

--
-- Table structure for table `emailver`
--

CREATE TABLE `emailver` (
  `NAME` text NOT NULL,
  `PASS` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emailver`
--

INSERT INTO `emailver` (`NAME`, `PASS`, `EMAIL`) VALUES
('r', '789', 'hamza701973@gmail.com'),
('raffy', '789', 'alihamza_505@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `index`
--

CREATE TABLE `index` (
  `NAME` text NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newpatient`
--

CREATE TABLE `newpatient` (
  `NAME` text NOT NULL,
  `GENDER` text NOT NULL,
  `AGE` int(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CONTNUM` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `USERNAME` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newpatient`
--

INSERT INTO `newpatient` (`NAME`, `GENDER`, `AGE`, `EMAIL`, `CONTNUM`, `ADDRESS`, `USERNAME`, `PASSWORD`) VALUES
('alihamza', 'MALE', 21, 'alihamza_505@yahoo.com', '03471106637', 'R-1015 sec 16/A BUFFERZONE ', 'ham', '123');

-- --------------------------------------------------------

--
-- Table structure for table `sea`
--

CREATE TABLE `sea` (
  `ID` int(6) NOT NULL,
  `NAME` text NOT NULL,
  `DATE` date NOT NULL,
  `DAY` text NOT NULL,
  `TIM` time(6) NOT NULL,
  `DOCTOR` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timing`
--

CREATE TABLE `timing` (
  `NAME` text NOT NULL,
  `DAY` text NOT NULL,
  `TIMING` time(6) NOT NULL,
  `TILL` time(6) NOT NULL,
  `VENUE` text NOT NULL,
  `SPEC` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timing`
--

INSERT INTO `timing` (`NAME`, `DAY`, `TIMING`, `TILL`, `VENUE`, `SPEC`) VALUES
('ALIHAMZA', 'MONDAY', '21:00:00.000000', '22:00:00.000000', '', ''),
('alihamza', 'MONDAY', '19:08:00.000000', '08:09:00.000000', '', ''),
('raffy', 'MONDAY', '21:08:00.000000', '17:08:00.000000', '', ''),
('alihamza', 'SUNDAY', '19:00:00.000000', '20:00:00.000000', 'ziauddin hospital', ''),
('alihamza', 'saturday', '19:00:00.000000', '20:00:00.000000', 'ziauddin hospital', ''),
('alihamza', 'SUNDAY', '19:00:00.000000', '23:00:00.000000', 'mumtaz clinic', ''),
('bond', 'monday', '06:00:00.000000', '07:00:00.000000', 'ziauddin hospital', ''),
('bond', 'wednesday', '06:00:00.000000', '11:00:00.000000', 'des', ''),
('sehan', 'SUNDAY', '21:00:00.000000', '22:00:00.000000', 'karachi ', 'GENERAL SURGEON');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sea`
--
ALTER TABLE `sea`
  ADD PRIMARY KEY (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
